export class Estacion {
  id: number;
  nombre: string;
  direccion: string;
  lineas: number[];  
}
